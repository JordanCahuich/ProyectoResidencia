

<?php $__env->startSection('content'); ?>
        
<?php if( session('updateAlumno') ): ?>
<div class="row re" id="proBanner">
    <div class="col-md-12 grid-margin">
      <div class="card bg-gradient-primary border-0">
        <div class="card-body py-3 px-4 d-flex align-items-center justify-content-between flex-wrap">
          <p class="mb-0 text-white font-weight-medium" style="margin: 0 auto;">
            <strong>Felicitaciones !</strong>
            <?php echo e(session('updateAlumno')); ?>

          </p>
          
          <div class="d-flex">
            <button id="bannerClose" class="btn border-0 p-0">
              <i class="mdi mdi-close text-white"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
    </div>
<?php endif; ?>

<?php if( session('mensaje') ): ?>
<div class="row re" id="proBanner">
    <div class="col-md-12 grid-margin">
      <div class="card bg-gradient-primary border-0">
        <div class="card-body py-3 px-4 d-flex align-items-center justify-content-between flex-wrap">
          <p class="mb-0 text-white font-weight-medium" style="margin: 0 auto;">
            <strong>Felicitaciones !</strong>
            <?php echo e(session('mensaje')); ?>

          </p>
          
          <div class="d-flex">
            <button id="bannerClose" class="btn border-0 p-0">
              <i class="mdi mdi-close text-white"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
    </div>
<?php endif; ?>


<?php if(!empty($alumnos)): ?>
<div class="col-md-12 grid-margin stretch-card">
<div class="card">
    <div class="card-body">
    <h4 class="card-title text-center">LISTA DE ALUMNOS  </strong>
      <hr>
      <!--  <a class="btn btn-inverse-primary" href="<?php echo e(route('exportAlumnos')); ?>"  style="padding: 8px 15px !important;" title="Ver Detalles"> Descargar</a>-->
    </h4>
    <div class="table-responsive">
        <table id="datatables-example" class="table table-hover">
        <thead>
            <tr>
            <th>Nombre del Alumno</th>
            <th>Sexo</th>
            <th>Grado</th>
            <th>CURP</th>
            <th>NIVEL</th>
            <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($alumno->nombre); ?></td>
                <td><?php echo e($alumno->sexo); ?></td>
                <td><?php echo e($alumno->grado); ?></td>
                <td><?php echo e($alumno->curp); ?></td>
                <td><?php echo e($alumno->nivel_escolar); ?></td>

                <td style="float: right">
                         <a class="btn btn-inverse-primary" href="<?php echo e(route('alumno.show',$alumno->id)); ?>"  style="padding: 8px 15px !important;" title="Ver Detalles">
                            <i class="mdi mdi-account-card-details"></i> Ver
                        </a>
                        <a class="btn btn-inverse-success" href="<?php echo e(route('alumno.edit',$alumno->id)); ?>"  style="padding: 8px 5px !important;" title="Actualizar Registro">
                            <i class="mdi mdi-autorenew"></i>Actualizar
                        </a>
                        <?php echo csrf_field(); ?>
                        
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-inverse-danger" onclick="return confirm('Estas seguro que deseas borrar el alumno: <?php echo e($alumno->nombre); ?> ?');"  style="padding:  8px 5px !important;" title="Borrar Alumno">
                            <i class="mdi mdi-delete-sweep"></i>Borrar
                        </button>
                        
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>

        <br><br>
        <div class="form-group text-center mt5">
            <?php echo $alumnos->links(); ?>

        </div>

        </div>
    </div>
</div>
</div>
<?php else: ?>
<p> No se han creado Alumnos </p>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoResidencia\resources\views/alumnos/index.blade.php ENDPATH**/ ?>