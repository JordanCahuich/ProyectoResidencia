<script src="<?php echo e(asset('vendors/base/vendor.bundle.base.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/chart.js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js"></script> 
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>


<script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
<script src="<?php echo e(asset('js/hoverable-collapse.js')); ?>"></script>
<script src="<?php echo e(asset('js/template.js')); ?>"></script>

<script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('js/data-table.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.js')); ?>"></script>

<script src="<?php echo e(asset('js/mis_Scripts.js')); ?>"></script>

<script src="<?php echo e(asset('js/barra/pace.min.js')); ?>"></script> <!--barra de carga --><?php /**PATH C:\xampp\htdocs\ProyectoResidencia\resources\views/layouts/layoutJS.blade.php ENDPATH**/ ?>